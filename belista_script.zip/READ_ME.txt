This version is absolutely free for personal, educational, non-profit, or charitable use.

You can't use for commercial.